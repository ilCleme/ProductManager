<?php

namespace Acme\DemoBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * TblCatalogueCategory
 *
 * @ORM\Table(name="tbl_catalogue_category")
 * @ORM\Entity
 */
class TblCatalogueCategory
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id_tbl_catalogue_category", type="bigint", nullable=false)
     */
    private $idTblCatalogueCategory;

    /**
     * @var boolean
     *
     * @ORM\Column(name="id_tbl_lingua", type="boolean", nullable=false)
     */
    private $idTblLingua;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255, nullable=false)
     */
    private $title;

    /**
     * @var string
     *
     * @ORM\Column(name="description", type="string", length=255, nullable=true)
     */
    private $description;

    /**
     * @var string
     *
     * @ORM\Column(name="img", type="string", length=255, nullable=true)
     */
    private $img;

    /**
     * @var boolean
     *
     * @ORM\Column(name="pub", type="boolean", nullable=false)
     */
    private $pub;

    /**
     * @var integer
     *
     * @ORM\Column(name="position", type="integer", nullable=false)
     */
    private $position;

    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="bigint")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
     */
    private $id;

    /**
     * @ORM\ManyToMany(targetEntity="Acme\DemoBundle\Entity\TblCatalogueProduct", mappedBy="categories")
     **/
    private $products;
    
    /**
     * @ORM\ManyToMany(targetEntity="Acme\DemoBundle\Entity\TblCatalogueCategory", mappedBy="myFriends")
     **/
    protected $friendsWithMe;

    /**
     * @ORM\ManyToMany(targetEntity="Acme\DemoBundle\Entity\TblCatalogueCategory", inversedBy="friendsWithMe")
     * @ORM\JoinTable(name="cross_tbl_catalogue_category_x_tbl_catalogue_category",
     *      joinColumns={@ORM\JoinColumn(name="id_item", referencedColumnName="id_tbl_catalogue_category")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="id_parent", referencedColumnName="id_tbl_catalogue_category")}
     *      )
     **/
    protected $myFriends;
    
    
    public function __construct() {
        $this->products = new \Doctrine\Common\Collections\ArrayCollection();
        $this->friendsWithMe = new \Doctrine\Common\Collections\ArrayCollection();
        $this->myFriends = new \Doctrine\Common\Collections\ArrayCollection();
    }


    /**
     * Set idTblCatalogueCategory
     *
     * @param integer $idTblCatalogueCategory
     * @return TblCatalogueCategory
     */
    public function setIdTblCatalogueCategory($idTblCatalogueCategory)
    {
        $this->idTblCatalogueCategory = $idTblCatalogueCategory;

        return $this;
    }

    /**
     * Get idTblCatalogueCategory
     *
     * @return integer 
     */
    public function getIdTblCatalogueCategory()
    {
        return $this->idTblCatalogueCategory;
    }

    /**
     * Set idTblLingua
     *
     * @param boolean $idTblLingua
     * @return TblCatalogueCategory
     */
    public function setIdTblLingua($idTblLingua)
    {
        $this->idTblLingua = $idTblLingua;

        return $this;
    }

    /**
     * Get idTblLingua
     *
     * @return boolean 
     */
    public function getIdTblLingua()
    {
        return $this->idTblLingua;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return TblCatalogueCategory
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string 
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set description
     *
     * @param string $description
     * @return TblCatalogueCategory
     */
    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    /**
     * Get description
     *
     * @return string 
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * Set img
     *
     * @param string $img
     * @return TblCatalogueCategory
     */
    public function setImg($img)
    {
        $this->img = $img;

        return $this;
    }

    /**
     * Get img
     *
     * @return string 
     */
    public function getImg()
    {
        return $this->img;
    }

    /**
     * Set pub
     *
     * @param boolean $pub
     * @return TblCatalogueCategory
     */
    public function setPub($pub)
    {
        $this->pub = $pub;

        return $this;
    }

    /**
     * Get pub
     *
     * @return boolean 
     */
    public function getPub()
    {
        return $this->pub;
    }

    /**
     * Set position
     *
     * @param integer $position
     * @return TblCatalogueCategory
     */
    public function setPosition($position)
    {
        $this->position = $position;

        return $this;
    }

    /**
     * Get position
     *
     * @return integer 
     */
    public function getPosition()
    {
        return $this->position;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Add products
     *
     * @param \Acme\DemoBundle\Entity\TblCatalogueProduct $products
     * @return TblCatalogueCategory
     */
    public function addProduct(\Acme\DemoBundle\Entity\TblCatalogueProduct $products)
    {
        $this->products[] = $products;

        return $this;
    }

    /**
     * Remove products
     *
     * @param \Acme\DemoBundle\Entity\TblCatalogueProduct $products
     */
    public function removeProduct(\Acme\DemoBundle\Entity\TblCatalogueProduct $products)
    {
        $this->products->removeElement($products);
    }

    /**
     * Get products
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getProducts()
    {
        return $this->products;
    }

    /**
     * Add friendsWithMe
     *
     * @param \Acme\DemoBundle\Entity\TblCatalogueCategory $friendsWithMe
     * @return TblCatalogueCategory
     */
    public function addFriendsWithMe(\Acme\DemoBundle\Entity\TblCatalogueCategory $friendsWithMe)
    {
        $this->friendsWithMe[] = $friendsWithMe;

        return $this;
    }

    /**
     * Remove friendsWithMe
     *
     * @param \Acme\DemoBundle\Entity\TblCatalogueCategory $friendsWithMe
     */
    public function removeFriendsWithMe(\Acme\DemoBundle\Entity\TblCatalogueCategory $friendsWithMe)
    {
        $this->friendsWithMe->removeElement($friendsWithMe);
    }

    /**
     * Get friendsWithMe
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getFriendsWithMe()
    {
        return $this->friendsWithMe;
    }

    /**
     * Add myFriends
     *
     * @param \Acme\DemoBundle\Entity\TblCatalogueCategory $myFriends
     * @return TblCatalogueCategory
     */
    public function addMyFriend(\Acme\DemoBundle\Entity\TblCatalogueCategory $myFriends)
    {
        $this->myFriends[] = $myFriends;

        return $this;
    }

    /**
     * Remove myFriends
     *
     * @param \Acme\DemoBundle\Entity\TblCatalogueCategory $myFriends
     */
    public function removeMyFriend(\Acme\DemoBundle\Entity\TblCatalogueCategory $myFriends)
    {
        $this->myFriends->removeElement($myFriends);
    }

    /**
     * Get myFriends
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getMyFriends()
    {
        return $this->myFriends;
    }
}
