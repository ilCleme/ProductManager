<?php

namespace QwebCMS\CatalogoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class QwebCMSCatalogoBundle extends Bundle
{
}
