<?php

namespace QwebCMS\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class QwebCMSUserBundle extends Bundle
{
}
