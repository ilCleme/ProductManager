<?php

/* QwebCMSCatalogoBundle:Welcome:showallcategory.html.twig */
class __TwigTemplate_f922e5f148cc9ba81d88569b40f2d808bfb2e072c35fd13281fa1ebd21f251d7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("layout.html.twig", "QwebCMSCatalogoBundle:Welcome:showallcategory.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Categorie";
    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
        // line 7
        echo "<div class=\"ibox float-e-margins\">
    <div class=\"ibox-title\">
        <h5>Categorie</h5>
        <div class=\"ibox-tools\">
            <a class=\"collapse-link\">
                <i class=\"fa fa-chevron-up\"></i>
            </a>
            <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                <i class=\"fa fa-wrench\"></i>
            </a>
            <!--<a class=\"close-link\">
                <i class=\"fa fa-times\"></i>
            </a>-->
        </div>
    </div>
    <div class=\"ibox-content\">
        <div class=\"table-responsive\">
            <table class=\"table table-striped\" >
                <thead>
                <tr>
                    <th>#</th>
                    <th>Nome Categoria</th>
                    <th>Descrizione</th>
                    <th>Azioni</th>
                </tr>
                </thead>
                <tbody>
                    ";
        // line 34
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 35
            echo "                    <tr>
                        <td>
                            ";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "idTblCatalogueCategory", array()), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "title", array()), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "description", array()), "html", null, true);
            echo "
                        </td>
                        <td>
                            <a href=\"/category/update/";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "idTblCatalogueCategory", array()), "html", null, true);
            echo "\" title=\"Modifica\"><i class=\"fa fa-edit\"></i></a>
                        </td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "                </tbody>
            </table>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "QwebCMSCatalogoBundle:Welcome:showallcategory.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 50,  93 => 46,  87 => 43,  81 => 40,  75 => 37,  71 => 35,  67 => 34,  38 => 7,  35 => 6,  29 => 4,  11 => 2,);
    }
}
