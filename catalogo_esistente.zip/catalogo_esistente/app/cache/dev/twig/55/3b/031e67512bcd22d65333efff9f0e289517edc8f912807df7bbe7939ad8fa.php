<?php

/* AcmeDemoBundle:Featurevalue:showfeature.html.twig */
class __TwigTemplate_553b031e67512bcd22d65333efff9f0e289517edc8f912807df7bbe7939ad8fa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("::base.html.twig", "AcmeDemoBundle:Featurevalue:showfeature.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Categoria di Caratteristiche";
    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 7
        echo "    <link href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css\" rel=\"stylesheet\">    
";
    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        // line 11
        echo "    <div class=\"container\">
        <div class=\"panel panel-default\">
            <!-- Default panel contents -->
            <div class=\"panel-heading\"><h1>Categoria ";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["feature"]) ? $context["feature"] : $this->getContext($context, "feature")), "title", array()), "html", null, true);
        echo "</h1></div>
            
            <!-- List Group -->
            <ul class=\"list-group\">
                <li class=\"list-group-item\">Nome categoria: ";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["feature"]) ? $context["feature"] : $this->getContext($context, "feature")), "title", array()), "html", null, true);
        echo "</li>
                <li class=\"list-group-item\">Descrizione: ";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["feature"]) ? $context["feature"] : $this->getContext($context, "feature")), "description", array()), "html", null, true);
        echo "</li>
            </ul>
        </div>
    </div>
";
    }

    // line 25
    public function block_javascripts($context, array $blocks = array())
    {
        // line 26
        echo "    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js\"></script>
    <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js\"></script>    
";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Featurevalue:showfeature.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 26,  73 => 25,  64 => 19,  60 => 18,  53 => 14,  48 => 11,  45 => 10,  40 => 7,  37 => 6,  31 => 4,  11 => 2,);
    }
}
