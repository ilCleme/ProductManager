<?php

/* AcmeDemoBundle:Welcome:showallfeatures.html.twig */
class __TwigTemplate_bba9a953482d0fed8e16696494d3a675792a82f06c6b2d6e8ba9d417dae012ed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("::base.html.twig", "AcmeDemoBundle:Welcome:showallfeatures.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Caratteristiche";
    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 7
        echo "    <link href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css\" rel=\"stylesheet\">    
";
    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        // line 11
        echo "<div class=\"container\">
    <div class=\"panel panel-default\">
        <!-- Default panel contents -->
        <div class=\"panel-heading\"><h1>Caratteristiche</h1></div>
        <div class=\"panel-body\">
            <p>Elenco di tutte le Caratteristiche</p>
        </div>
        
        <!-- Table -->
        <table class=\"table\">
            
            ";
        // line 22
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["features"]) ? $context["features"] : $this->getContext($context, "features")));
        foreach ($context['_seq'] as $context["_key"] => $context["feature"]) {
            // line 23
            echo "            <tr>
                <td>
                    ";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["feature"], "title", array()), "html", null, true);
            echo "
                </td>
                <td>
                    ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["feature"], "description", array()), "html", null, true);
            echo "
                </td>
                <td>
                    ";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["feature"], "typeInput", array()), "html", null, true);
            echo "
                </td>
            </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['feature'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "            
        </table>
    </div>
</div>
";
    }

    // line 41
    public function block_javascripts($context, array $blocks = array())
    {
        // line 42
        echo "<script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js\"></script>    
";
    }

    public function getTemplateName()
    {
        return "AcmeDemoBundle:Welcome:showallfeatures.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 42,  99 => 41,  91 => 35,  81 => 31,  75 => 28,  69 => 25,  65 => 23,  61 => 22,  48 => 11,  45 => 10,  40 => 7,  37 => 6,  31 => 4,  11 => 2,);
    }
}
