<?php

/* QwebCMSCatalogoBundle:Welcome:showallproduct.html.twig */
class __TwigTemplate_e7539a325c2b1b002dd987389ff12f6cc64c4e3793298e2ed638a62c08bceec2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("::layout.html.twig", "QwebCMSCatalogoBundle:Welcome:showallproduct.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Prodotti";
    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
        // line 7
        echo "<div class=\"ibox float-e-margins\">
    <div class=\"ibox-title\">
        <h5>Prodotti</h5>
        <div class=\"ibox-tools\">
            <a class=\"collapse-link\">
                <i class=\"fa fa-chevron-up\"></i>
            </a>
            <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                <i class=\"fa fa-wrench\"></i>
            </a>
            <!--<a class=\"close-link\">
                <i class=\"fa fa-times\"></i>
            </a>-->
        </div>
    </div>
    <div class=\"ibox-content\">
        <div class=\"table-responsive\">
            <table class=\"table table-striped\" >
                <thead>
                <tr>
                    <th>#</th>
                    <th>Nome Prodotto</th>
                    <th>Descrizione</th>
                    <th>Azioni</th>
                </tr>
                </thead>
                <tbody>
                    ";
        // line 34
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["products"]) ? $context["products"] : $this->getContext($context, "products")));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 35
            echo "                    <tr>
                        <td>
                            ";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "idTblCatalogueProduct", array()), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "title", array()), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "shortDescription", array()), "html", null, true);
            echo "
                        </td>
                        <td>
                            <a href=\"/product/update/";
            // line 46
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "idTblCatalogueProduct", array()), "html", null, true);
            echo "\" title=\"Modifica\"><i class=\"fa fa-edit\"></i></a>
                        </td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "                </tbody>
            </table>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "QwebCMSCatalogoBundle:Welcome:showallproduct.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 50,  93 => 46,  87 => 43,  81 => 40,  75 => 37,  71 => 35,  67 => 34,  38 => 7,  35 => 6,  29 => 4,  11 => 2,);
    }
}
