<?php

/* QwebCMSCatalogoBundle:Welcome:showallfeaturevalues.html.twig */
class __TwigTemplate_cb740919485358455135c87fb58ddfcab5605d332faaafef5447c87150feb36e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("::layout.html.twig", "QwebCMSCatalogoBundle:Welcome:showallfeaturevalues.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Featurevalues";
    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
        // line 7
        echo "<div class=\"ibox float-e-margins\">
    <div class=\"ibox-title\">
        <h5>Prodotti</h5>
        <div class=\"ibox-tools\">
            <a class=\"collapse-link\">
                <i class=\"fa fa-chevron-up\"></i>
            </a>
            <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                <i class=\"fa fa-wrench\"></i>
            </a>
            <!--<a class=\"close-link\">
                <i class=\"fa fa-times\"></i>
            </a>-->
        </div>
    </div>
    <div class=\"ibox-content\">
        <div class=\"table-responsive\">
            <table class=\"table table-striped\" >
                <thead>
                <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>Descrizione</th>
                    <th>Immagine</th>
                    <th>Azione</th>
                </tr>
                </thead>
                <tbody>
                    ";
        // line 35
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["featurevalues"]) ? $context["featurevalues"] : $this->getContext($context, "featurevalues")));
        foreach ($context['_seq'] as $context["_key"] => $context["featurevalue"]) {
            // line 36
            echo "                    <tr>
                        <td>
                            ";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute($context["featurevalue"], "idTblCatalogueFeaturevalue", array()), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["featurevalue"], "title", array()), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["featurevalue"], "link", array()), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute($context["featurevalue"], "img", array()), "html", null, true);
            echo "
                        </td>
                        ";
            // line 52
            echo "                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['featurevalue'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 54
        echo "                </tbody>
            </table>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "QwebCMSCatalogoBundle:Welcome:showallfeaturevalues.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 54,  99 => 52,  94 => 47,  88 => 44,  82 => 41,  76 => 38,  72 => 36,  68 => 35,  38 => 7,  35 => 6,  29 => 4,  11 => 2,);
    }
}
