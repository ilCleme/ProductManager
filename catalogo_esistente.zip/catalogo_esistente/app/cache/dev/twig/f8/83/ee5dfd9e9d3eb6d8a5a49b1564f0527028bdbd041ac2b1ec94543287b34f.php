<?php

/* QwebCMSCatalogoBundle:Welcome:showallfeatures.html.twig */
class __TwigTemplate_f883ee5dfd9e9d3eb6d8a5a49b1564f0527028bdbd041ac2b1ec94543287b34f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("::layout.html.twig", "QwebCMSCatalogoBundle:Welcome:showallfeatures.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Caratteristiche";
    }

    // line 6
    public function block_content($context, array $blocks = array())
    {
        // line 7
        echo "<div class=\"ibox float-e-margins\">
    <div class=\"ibox-title\">
        <h5>Prodotti</h5>
        <div class=\"ibox-tools\">
            <a class=\"collapse-link\">
                <i class=\"fa fa-chevron-up\"></i>
            </a>
            <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                <i class=\"fa fa-wrench\"></i>
            </a>
            <!--<a class=\"close-link\">
                <i class=\"fa fa-times\"></i>
            </a>-->
        </div>
    </div>
    <div class=\"ibox-content\">
        <div class=\"table-responsive\">
            <table class=\"table table-striped\" >
                <thead>
                <tr>
                    <th>#</th>
                    <th>Nome</th>
                    <th>Descrizione</th>
                    <th>Tipo di input</th>
                    <th>Azione</th>
                </tr>
                </thead>
                <tbody>
                    ";
        // line 35
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["features"]) ? $context["features"] : $this->getContext($context, "features")));
        foreach ($context['_seq'] as $context["_key"] => $context["feature"]) {
            // line 36
            echo "                    <tr>
                        <td>
                            ";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute($context["feature"], "idTblCatalogueFeature", array()), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 41
            echo twig_escape_filter($this->env, $this->getAttribute($context["feature"], "title", array()), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($context["feature"], "description", array()), "html", null, true);
            echo "
                        </td>
                        <td>
                            ";
            // line 47
            echo twig_escape_filter($this->env, $this->getAttribute($context["feature"], "typeInput", array()), "html", null, true);
            echo "
                        </td>
                        <td>
                            <a href=\"/feature/update/";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($context["feature"], "idTblCatalogueFeature", array()), "html", null, true);
            echo "\" title=\"Modifica\"><i class=\"fa fa-edit\"></i></a>
                        </td>
                    </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['feature'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 54
        echo "                </tbody>
            </table>
        </div>
    </div>
</div>
";
    }

    public function getTemplateName()
    {
        return "QwebCMSCatalogoBundle:Welcome:showallfeatures.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 54,  100 => 50,  94 => 47,  88 => 44,  82 => 41,  76 => 38,  72 => 36,  68 => 35,  38 => 7,  35 => 6,  29 => 4,  11 => 2,);
    }
}
