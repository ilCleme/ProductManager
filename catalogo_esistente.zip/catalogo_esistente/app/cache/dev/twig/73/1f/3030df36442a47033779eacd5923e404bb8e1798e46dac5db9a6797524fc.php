<?php

/* QwebCMSCatalogoBundle:Welcome:index.html.twig */
class __TwigTemplate_731f3030df36442a47033779eacd5923e404bb8e1798e46dac5db9a6797524fc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::layout.html.twig", "QwebCMSCatalogoBundle:Welcome:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Dashboard";
    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        // line 6
        echo "    <div class=\"row\">
        <div class=\"col-lg-3\">
            <div class=\"ibox float-e-margins\">
                <div class=\"ibox-title\">
                    ";
        // line 11
        echo "                    <h5>Prodotti</h5>
                </div>
                <div class=\"ibox-content\">
                    <h1 class=\"no-margins\">";
        // line 14
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["products"]) ? $context["products"] : $this->getContext($context, "products"))), "html", null, true);
        echo "</h1>
                    ";
        // line 16
        echo "                    <small>Prodotti presenti</small>
                </div>
            </div>
        </div>
        <div class=\"col-lg-3\">
            <div class=\"ibox float-e-margins\">
                <div class=\"ibox-title\">
                    ";
        // line 24
        echo "                    <h5>Categorie</h5>
                </div>
                <div class=\"ibox-content\">
                    <h1 class=\"no-margins\">";
        // line 27
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories"))), "html", null, true);
        echo "</h1>
                    ";
        // line 29
        echo "                    <small>Categorie presenti</small>
                </div>
            </div>
        </div>
        <div class=\"col-lg-3\">
            <div class=\"ibox float-e-margins\">
                <div class=\"ibox-title\">
                    ";
        // line 37
        echo "                    <h5>Feature</h5>
                </div>
                <div class=\"ibox-content\">
                    <h1 class=\"no-margins\">";
        // line 40
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["features"]) ? $context["features"] : $this->getContext($context, "features"))), "html", null, true);
        echo "</h1>
                    ";
        // line 42
        echo "                    <small>Feature presenti</small>
                </div>
            </div>
        </div>
        <div class=\"col-lg-3\">
            <div class=\"ibox float-e-margins\">
                <div class=\"ibox-title\">
                    ";
        // line 50
        echo "                    <h5>Featurevalues</h5>
                </div>
                <div class=\"ibox-content\">
                    <h1 class=\"no-margins\">";
        // line 53
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["featurevalues"]) ? $context["featurevalues"] : $this->getContext($context, "featurevalues"))), "html", null, true);
        echo "</h1>
                    ";
        // line 55
        echo "                    <small>Featurevalues presenti</small>
                </div>
            </div>
        </div>
    </div>

    ";
        // line 62
        echo "    <div class=\"ibox float-e-margins\">
        <div class=\"ibox-title\">
            <h5>Categorie</h5>
            <div class=\"ibox-tools\">
                <a class=\"collapse-link\">
                    <i class=\"fa fa-chevron-up\"></i>
                </a>
                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                    <i class=\"fa fa-wrench\"></i>
                </a>
                <!--<a class=\"close-link\">
                    <i class=\"fa fa-times\"></i>
                </a>-->
            </div>
        </div>
        <div class=\"ibox-content\">
            <div class=\"table-responsive\">
                <table class=\"table table-striped\" >
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome Categoria</th>
                        <th>Descrizione</th>
                        <th>Azioni</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 89
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        foreach ($context['_seq'] as $context["_key"] => $context["category"]) {
            // line 90
            echo "                        <tr>
                            <td>
                                ";
            // line 92
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "idTblCatalogueCategory", array()), "html", null, true);
            echo "
                            </td>
                            <td>
                                ";
            // line 95
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "title", array()), "html", null, true);
            echo "
                            </td>
                            <td>
                                ";
            // line 98
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "description", array()), "html", null, true);
            echo "
                            </td>
                            <td>
                                <a href=\"/category/update/";
            // line 101
            echo twig_escape_filter($this->env, $this->getAttribute($context["category"], "idTblCatalogueCategory", array()), "html", null, true);
            echo "\" title=\"Modifica\"><i class=\"fa fa-edit\"></i></a>
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['category'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 105
        echo "                    </tbody>
                </table>
            </div>
        </div>
    </div>

    ";
        // line 112
        echo "    <div class=\"ibox float-e-margins\">
        <div class=\"ibox-title\">
            <h5>Prodotti</h5>
            <div class=\"ibox-tools\">
                <a class=\"collapse-link\">
                    <i class=\"fa fa-chevron-up\"></i>
                </a>
                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"#\">
                    <i class=\"fa fa-wrench\"></i>
                </a>
                <!--<a class=\"close-link\">
                    <i class=\"fa fa-times\"></i>
                </a>-->
            </div>
        </div>
        <div class=\"ibox-content\">
            <div class=\"table-responsive\">
                <table class=\"table table-striped\" >
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome Prodotto</th>
                        <th>Descrizione</th>
                        <th>Azioni</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 139
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["products"]) ? $context["products"] : $this->getContext($context, "products")));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 140
            echo "                        <tr>
                            <td>
                                ";
            // line 142
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "idTblCatalogueProduct", array()), "html", null, true);
            echo "
                            </td>
                            <td>
                                ";
            // line 145
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "title", array()), "html", null, true);
            echo "
                            </td>
                            <td>
                                ";
            // line 148
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "shortDescription", array()), "html", null, true);
            echo "
                            </td>
                            <td>
                                <a href=\"/product/update/";
            // line 151
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "idTblCatalogueProduct", array()), "html", null, true);
            echo "\" title=\"Modifica\"><i class=\"fa fa-edit\"></i></a>
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 155
        echo "                    </tbody>
                </table>
            </div>
        </div>
    </div>

";
    }

    public function getTemplateName()
    {
        return "QwebCMSCatalogoBundle:Welcome:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  253 => 155,  243 => 151,  237 => 148,  231 => 145,  225 => 142,  221 => 140,  217 => 139,  188 => 112,  180 => 105,  170 => 101,  164 => 98,  158 => 95,  152 => 92,  148 => 90,  144 => 89,  115 => 62,  107 => 55,  103 => 53,  98 => 50,  89 => 42,  85 => 40,  80 => 37,  71 => 29,  67 => 27,  62 => 24,  53 => 16,  49 => 14,  44 => 11,  38 => 6,  35 => 5,  29 => 3,  11 => 1,);
    }
}
