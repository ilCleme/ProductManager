<?php

/* ::layout.html.twig */
class __TwigTemplate_3210d775000e8c8e6f3bd2c33a2a6506c856d5e95c97d4bcbf07ead7995ae5d8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'sidebar' => array($this, 'block_sidebar'),
            'content' => array($this, 'block_content'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
<head>

    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">

    <title>";
        // line 8
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

    <!-- CSS Files -->
    <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/font-awesome/css/font-awesome.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/css/animate.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

    <!-- Toastr style -->
    <link href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/css/plugins/toastr/toastr.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

    <!-- Gritter -->
    <link href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/gritter/jquery.gritter.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

    <link href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/css/animate.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
        
    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    <link href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("assets/css/demo.html5imageupload.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src=\"https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js\"></script>
      <script src=\"https://oss.maxcdn.com/respond/1.4.2/respond.min.js\"></script>
    <![endif]-->

    <script src=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("assets/js/html5imageupload.js?v1.4.3"), "html", null, true);
        echo "\"></script>
</head>
<body>
    <div id=\"wrapper\">
        <nav class=\"navbar-default navbar-static-side\" role=\"navigation\">
            <div class=\"sidebar-collapse\">
            ";
        // line 41
        $this->displayBlock('sidebar', $context, $blocks);
        // line 80
        echo "            </div>
        </nav>
    
        <div id=\"page-wrapper\" class=\"gray-bg dashbard-1\">
        <div class=\"row border-bottom\">
            <nav class=\"navbar navbar-static-top\" role=\"navigation\" style=\"margin-bottom: 0\">
                <div class=\"navbar-header\">
                    <a class=\"navbar-minimalize minimalize-styl-2 btn btn-primary \" href=\"#\"><i class=\"fa fa-bars\"></i> </a>
                    <form role=\"search\" class=\"navbar-form-custom\" action=\"search_results.html\">
                        <div class=\"form-group\">
                            <input type=\"text\" placeholder=\"Search for something...\" class=\"form-control\" name=\"top-search\" id=\"top-search\">
                        </div>
                    </form>
                </div>
                <ul class=\"nav navbar-top-links navbar-right\">
                    <li>
                        <a href=\"/logout\">
                            <i class=\"fa fa-sign-out\"></i> Log out
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        
        <div class=\"row\">
            <div class=\"col-lg-12\">
                <div class=\"wrapper wrapper-content\">
                    ";
        // line 107
        $this->displayBlock('content', $context, $blocks);
        // line 110
        echo "                    </div>
                    ";
        // line 111
        $this->displayBlock('footer', $context, $blocks);
        // line 121
        echo "                </div>
            </div>
        </div>
    </div>
    <!-- Mainly scripts -->
    <script src=\"";
        // line 126
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/jquery-2.1.1.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 127
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/metisMenu/jquery.metisMenu.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 129
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/slimscroll/jquery.slimscroll.min.js"), "html", null, true);
        echo "\"></script>

    <!-- Flot -->
    <script src=\"";
        // line 132
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/flot/jquery.flot.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 133
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/flot/jquery.flot.tooltip.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 134
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/flot/jquery.flot.spline.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 135
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/flot/jquery.flot.resize.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 136
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/flot/jquery.flot.pie.js"), "html", null, true);
        echo "\"></script>

    <!-- Peity -->
    <script src=\"";
        // line 139
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/peity/jquery.peity.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 140
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/demo/peity-demo.js"), "html", null, true);
        echo "\"></script>

    <!-- Custom and plugin javascript -->
    <script src=\"";
        // line 143
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/inspinia.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 144
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/pace/pace.min.js"), "html", null, true);
        echo "\"></script>

    <!-- jQuery UI -->
    <script src=\"";
        // line 147
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/jquery-ui/jquery-ui.min.js"), "html", null, true);
        echo "\"></script>

    <!-- GITTER -->
    <script src=\"";
        // line 150
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/gritter/jquery.gritter.min.js"), "html", null, true);
        echo "\"></script>

    <!-- Sparkline -->
    <script src=\"";
        // line 153
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/sparkline/jquery.sparkline.min.js"), "html", null, true);
        echo "\"></script>

    <!-- Sparkline demo data  -->
    <script src=\"";
        // line 156
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/demo/sparkline-demo.js"), "html", null, true);
        echo "\"></script>

    <!-- ChartJS-->
    <script src=\"";
        // line 159
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/chartJs/Chart.min.js"), "html", null, true);
        echo "\"></script>

    <!-- Toastr -->
    <script src=\"";
        // line 162
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("admin-style/js/plugins/toastr/toastr.min.js"), "html", null, true);
        echo "\"></script>


    <script>
        \$(document).ready(function() {
            //setTimeout(function() {
            //    toastr.options = {
            //        closeButton: true,
            //        progressBar: true,
            //        showMethod: 'slideDown',
            //        timeOut: 4000
            //    };
            //    toastr.success('Responsive Admin Theme', 'Welcome to INSPINIA');
            //
            //}, 1300);


            var data1 = [
                [0,4],[1,8],[2,5],[3,10],[4,4],[5,16],[6,5],[7,11],[8,6],[9,11],[10,30],[11,10],[12,13],[13,4],[14,3],[15,3],[16,6]
            ];
            var data2 = [
                [0,1],[1,0],[2,2],[3,0],[4,1],[5,3],[6,1],[7,5],[8,2],[9,3],[10,2],[11,1],[12,0],[13,2],[14,8],[15,0],[16,0]
            ];
            \$(\"#flot-dashboard-chart\").length && \$.plot(\$(\"#flot-dashboard-chart\"), [
                data1, data2
            ],
                    {
                        series: {
                            lines: {
                                show: false,
                                fill: true
                            },
                            splines: {
                                show: true,
                                tension: 0.4,
                                lineWidth: 1,
                                fill: 0.4
                            },
                            points: {
                                radius: 0,
                                show: true
                            },
                            shadowSize: 2
                        },
                        grid: {
                            hoverable: true,
                            clickable: true,
                            tickColor: \"#d5d5d5\",
                            borderWidth: 1,
                            color: '#d5d5d5'
                        },
                        colors: [\"#1ab394\", \"#464f88\"],
                        xaxis:{
                        },
                        yaxis: {
                            ticks: 4
                        },
                        tooltip: false
                    }
            );

            var doughnutData = [
                {
                    value: 300,
                    color: \"#a3e1d4\",
                    highlight: \"#1ab394\",
                    label: \"App\"
                },
                {
                    value: 50,
                    color: \"#dedede\",
                    highlight: \"#1ab394\",
                    label: \"Software\"
                },
                {
                    value: 100,
                    color: \"#b5b8cf\",
                    highlight: \"#1ab394\",
                    label: \"Laptop\"
                }
            ];

            var doughnutOptions = {
                segmentShowStroke: true,
                segmentStrokeColor: \"#fff\",
                segmentStrokeWidth: 2,
                percentageInnerCutout: 45, // This is 0 for Pie charts
                animationSteps: 100,
                animationEasing: \"easeOutBounce\",
                animateRotate: true,
                animateScale: false,
            };

            var ctx = document.getElementById(\"doughnutChart\").getContext(\"2d\");
            var DoughnutChart = new Chart(ctx).Doughnut(doughnutData, doughnutOptions);

            var polarData = [
                {
                    value: 300,
                    color: \"#a3e1d4\",
                    highlight: \"#1ab394\",
                    label: \"App\"
                },
                {
                    value: 140,
                    color: \"#dedede\",
                    highlight: \"#1ab394\",
                    label: \"Software\"
                },
                {
                    value: 200,
                    color: \"#b5b8cf\",
                    highlight: \"#1ab394\",
                    label: \"Laptop\"
                }
            ];

            var polarOptions = {
                scaleShowLabelBackdrop: true,
                scaleBackdropColor: \"rgba(255,255,255,0.75)\",
                scaleBeginAtZero: true,
                scaleBackdropPaddingY: 1,
                scaleBackdropPaddingX: 1,
                scaleShowLine: true,
                segmentShowStroke: true,
                segmentStrokeColor: \"#fff\",
                segmentStrokeWidth: 2,
                animationSteps: 100,
                animationEasing: \"easeOutBounce\",
                animateRotate: true,
                animateScale: false,
            };
            var ctx = document.getElementById(\"polarChart\").getContext(\"2d\");
            var Polarchart = new Chart(ctx).PolarArea(polarData, polarOptions);

        });
    </script>
</body>";
    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        echo " INSPINIA | Dashboard ";
    }

    // line 41
    public function block_sidebar($context, array $blocks = array())
    {
        // line 42
        echo "                <ul class=\"nav\" id=\"side-menu\">
                    <li class=\"nav-header\">
                        <div class=\"dropdown profile-element\">
                            <span>
                                <img alt=\"image\" class=\"img-circle\" src=\"img/profile_small.jpg\" />
                            </span>
                            <a data-toggle=\"dropdown\" class=\"dropdown-toggle\" href=\"#\">
                                <span class=\"clear\">
                                    <span class=\"block m-t-xs\">
                                        <strong class=\"font-bold\">";
        // line 51
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "nome", array()), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "cognome", array()), "html", null, true);
        echo "</strong>
                                    </span>
                                    <span class=\"text-muted text-xs block\">";
        // line 53
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
        echo "</span>
                                </span>
                            </a>
                            ";
        // line 63
        echo "                        </div>
                        <div class=\"logo-element\">
                            IN+
                        </div>
                    </li>
                    <li class=\"active\">
                        <a href=\"index.html\"><i class=\"fa fa-th-large\"></i> <span class=\"nav-label\">Catalogo</span> <span class=\"fa arrow\"></span></a>
                        <ul class=\"nav nav-second-level\">
                            <li class=\"active\"><a href=\"";
        // line 71
        echo $this->env->getExtension('routing')->getPath("products");
        echo "\">Prodotti</a></li>
                            <li ><a href=\"";
        // line 72
        echo $this->env->getExtension('routing')->getPath("categories");
        echo "\">Categorie</a></li>
                            <li ><a href=\"";
        // line 73
        echo $this->env->getExtension('routing')->getPath("features");
        echo "\">Feature</a></li>
                            <li ><a href=\"";
        // line 74
        echo $this->env->getExtension('routing')->getPath("featurevalues");
        echo "\">Featurevalues</a></li>
                        </ul>
                    </li>
                </ul>
            
            ";
    }

    // line 107
    public function block_content($context, array $blocks = array())
    {
        // line 108
        echo "                        
                    ";
    }

    // line 111
    public function block_footer($context, array $blocks = array())
    {
        // line 112
        echo "                    <div class=\"footer\">
                        <div class=\"pull-right\">
                            <a href=\"http://www-qweb.eu\">Credits</a>
                        </div>
                        <div>
                            <strong>Copyright</strong> Qwebsrl &copy; 2014-2015
                        </div>
                    </div>
                    ";
    }

    public function getTemplateName()
    {
        return "::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  454 => 112,  451 => 111,  446 => 108,  443 => 107,  433 => 74,  429 => 73,  425 => 72,  421 => 71,  411 => 63,  405 => 53,  398 => 51,  387 => 42,  384 => 41,  378 => 8,  236 => 162,  230 => 159,  224 => 156,  218 => 153,  212 => 150,  206 => 147,  200 => 144,  196 => 143,  190 => 140,  186 => 139,  180 => 136,  176 => 135,  172 => 134,  168 => 133,  164 => 132,  158 => 129,  154 => 128,  150 => 127,  146 => 126,  139 => 121,  137 => 111,  134 => 110,  132 => 107,  103 => 80,  101 => 41,  92 => 35,  80 => 26,  76 => 25,  71 => 23,  67 => 22,  62 => 20,  56 => 17,  50 => 14,  46 => 13,  42 => 12,  38 => 11,  32 => 8,  23 => 1,);
    }
}
